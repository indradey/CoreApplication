﻿using Microsoft.AspNetCore.Mvc;

namespace BethanysPieShop.Controllers
{
    public class AppExceptionController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
    }
}
